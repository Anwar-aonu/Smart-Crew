import React from "react"

function SignUp() {
  return <div name="signup"></div>
}
export default SignUp
